import React from 'react';
import Weather from './Weather'; // Import your Weather component
import './App.css';

function App() {
    return (
        <div>
            <h1>Weather App</h1>
            <Weather />  {/* Include the Weather component here */}
        </div>
    );
}

export default App;
