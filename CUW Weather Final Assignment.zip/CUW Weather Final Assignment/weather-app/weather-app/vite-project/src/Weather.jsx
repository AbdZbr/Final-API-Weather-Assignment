import React, { useState } from 'react';
import axios from 'axios';
import './Weather.css'; // Make sure this file is created

const Weather = () => {
    const [city, setCity] = useState('');
    const [weather, setWeather] = useState(null);
    const [error, setError] = useState(null);
    const [loading, setLoading] = useState(false);

    const getWeather = async (city) => {
        setLoading(true); // Start loading
        try {
            const response = await axios.get(`http://localhost:5000/weather?city=${city}`);
            setWeather(response.data);
            setError(null); // Clear any previous error
        } catch (err) {
            setError('Unable to fetch weather data. Please try again.');
            setWeather(null);
        } finally {
            setLoading(false); // Stop loading
        }
    };

    const handleSearch = (e) => {
        e.preventDefault();
        if (city.trim() !== '') {
            getWeather(city);
        }
    };

    return (
        <div className="weather-container">
            <form onSubmit={handleSearch} className="search-form">
                <input
                    type="text"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    placeholder="Enter city"
                    className="city-input"
                />
                <button type="submit" className="submit-button">Get Weather</button>
            </form>

            {loading && <p>Loading...</p>}

            {error && <p className="error">{error}</p>}

            {weather && (
                <div className="weather-info">
                    <h2>Weather in {weather.name}</h2>
                    <img 
                        src={`http://openweathermap.org/img/wn/${weather.weather[0].icon}.png`} 
                        alt={weather.weather[0].description}
                        className="weather-icon"
                    />
                    <p>Temperature: {weather.main.temp}°C</p>
                    <p>Feels like: {weather.main.feels_like}°C</p>
                    <p>Weather: {weather.weather[0].description}</p>
                    <p>Wind Speed: {weather.wind.speed} m/s</p>
                    <p>Humidity: {weather.main.humidity}%</p>
                    <p>Cloudiness: {weather.clouds.all}%</p>
                    <p>Sunrise: {new Date(weather.sys.sunrise * 1000).toLocaleTimeString()}</p>
                    <p>Sunset: {new Date(weather.sys.sunset * 1000).toLocaleTimeString()}</p>
                </div>
            )}
        </div>
    );
};

export default Weather;
